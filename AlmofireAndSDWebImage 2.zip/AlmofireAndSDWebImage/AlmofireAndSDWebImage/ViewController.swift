

import UIKit
import Alamofire

class ViewController: UIViewController
{

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var mob: UITextField!
    @IBOutlet weak var add: UITextField!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBAction func click(_ sender: Any)
    {
        /*Alamofire.request("http://localhost/KrimaDB/SerivceInsertInDB.php?id=\(id.text!)&name=\(name.text!)&address=\(add.text!)&mon=\(mob.text!)").responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            
           /* if let json = response.result.value {
                print("JSON: \(json)") // serialized json response
            }*/
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print("Data: \(utf8Text)") // original server data as UTF8 string
            }
        }*/
        

        //SerivceGetFromDB
        /*let parameters: Parameters = [
            "id": id.text!,
            "name": name.text!,
            "address": add.text!,
            "mon": mob.text!
        ]
        
        // All three of these calls are equivalent
        print(Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php", method: .post, parameters: parameters))
        print(Alamofire.request("http://localhost/KrimaDB/PostShowData.php", method: .post, parameters: parameters, encoding: URLEncoding.default))
        print(Alamofire.request("http://localhost/KrimaDB/PostShowData.php", method: .post, parameters: parameters, encoding: URLEncoding.httpBody))*/
    }
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        
        /*Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php?name=Krima&address=surat").responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            //print(response.result.value ?? "Error")
            
            
            if let json = response.result.value
            {
                print("JSON: \(json)") // serialized json response
            }
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8)
            {
                print("Data: \(utf8Text)") // original server data as UTF8 string
            }
        }*/

    
        Alamofire.request("http://localhost/KrimaDB/GetImage.php").responseJSON { response in
            //print("Request: \(String(describing: response.request))")   // original url request
            //print("Response: \(String(describing: response.response))") // http url response
            //print("Result: \(response.result)")                         // response serialization result
            //print(response.result.value ?? "Error")
            
            
            /*if let json = response.result.value
            {
                print("JSON: \(json)") // serialized json response
            }*/
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8)
            {
                print("Data: \(utf8Text)") // original server data as UTF8 string
            }
        }
        /*Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php?name=Krima&address=surat").responseJSON { response in
            debugPrint(response)
            
            if let json = response.result.value {
                print("JSON: \(json)")
            }
        }*/
        /*Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php?name=Krima&address=surat")
            .responseString { response in
                print("Response String: \(response.result.value!)")
            }
            .responseJSON { response in
                print("Response JSON: \(response.result.value!)")
        }*/
        /*let utilityQueue = DispatchQueue.global(qos: .utility)
        
        Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php?name=Krima&address=surat").responseJSON(queue: utilityQueue) { response in
            print("Response JSON: \(response.result.value!)")
            print("Executing response handler on utility queue")
            
        }*/
        
        /*Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php?name=Krima&address=surat")
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                case .failure(let error):
                    print(error)
                }
        }*/
        /*Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php?name=Krima&address=surat").validate().responseJSON { response in
            switch response.result {
            case .success:
                print("Validation Successful")
            case .failure(let error):
                print(error)
            }
        }*/
        /*let parameters: Parameters = ["name": "Krima","address":"surat"]
        
        // All three of these calls are equivalent
        print(Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php", parameters: parameters) )// encoding defaults to `URLEncoding.default`
        Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php", parameters: parameters, encoding: URLEncoding.default)
        Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php", parameters: parameters, encoding: URLEncoding(destination: .methodDependent))*/

        /*let parameters: Parameters = [
            "id": "1",
            "name": "Krima",
            "address": "surat",
            "mon": "1111111111"
        ]
        
        // All three of these calls are equivalent
        print(Alamofire.request("http://localhost/KrimaDB/ShowFromRegister.php", method: .post, parameters: parameters))
        print(Alamofire.request("http://localhost/KrimaDB/PostShowData.php", method: .post, parameters: parameters, encoding: URLEncoding.default))
        print(Alamofire.request("http://localhost/KrimaDB/PostShowData.php", method: .post, parameters: parameters, encoding: URLEncoding.httpBody))
        
        // HTTP body: foo=bar&baz[]=a&baz[]=1&qux[x]=1&qux[y]=2&qux[z]=3*/
        
        
        /*let parameters: Parameters = [
            "name": "Krima",
            "id":"1",
            "address": "surat",
            "mon": "1111111111"
            ]
        
        // Both calls are equivalent
        print(Alamofire.request("http://localhost/KrimaDB/ShowFromRegister.php", method: .post, parameters: parameters, encoding: JSONEncoding.default))
        print(Alamofire.request("http://localhost/KrimaDB/PostShowData.php", method: .post, parameters: parameters, encoding: JSONEncoding(options: [])))
        
        // HTTP body: {"foo": [1, 2, 3], "bar": {"baz": "qux"}}*/
        
        
        /*struct JSONStringArrayEncoding: ParameterEncoding {
            private var array: [String] = ["Krima","surat"]
            
            init(array: [String]) {
                self.array = array
            }
            
            func encode(_ urlRequest: URLRequestConvertible, with parameters: Parameters?) throws -> URLRequest {
                var urlRequest = try urlRequest.asURLRequest()
                
                let data = try JSONSerialization.data(withJSONObject: array, options: [])
                
                if urlRequest.value(forHTTPHeaderField: "Content-Type") == nil {
                    urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
                }
                
                urlRequest.httpBody = data
                
                return urlRequest
            }
        }*/
        
        /*let url = URL(string: "http://localhost/KrimaDB/PostShowData.php")!
        let urlRequest = URLRequest(url: url)
        
        let parameters: Parameters = ["id": "1"]
        do{
        let encodedURLRequest = try URLEncoding.queryString.encode(urlRequest, with: parameters)
            print(encodedURLRequest)
        }
        catch{}*/
        
        /*let headers: HTTPHeaders = [
            "id": "1",
            "name": "Krima"
        ]
        
        Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php", headers: headers).responseJSON { response in
            debugPrint(response)//.result.value ?? "dxfjh")
        }*/
        
        /*let id = "1"
        let name = "Krima"
        
        Alamofire.request("http://localhost/KrimaDB/SerivceGetFromDB.php/\(id)/\(name)")
            .authenticate(user: id, password: name)
            .responseJSON { response in
                debugPrint(response)
        }*/
        
        Alamofire.download("http://localhost/KrimaDB/images").responseData { response in
            if let data = response.result.value {
                let image = UIImage(data: data)
                print(image!)
                self.img.image = image!
                //img.image = UIImage(named: image)
            }
        }
        
       /*let parameters: Parameters = [
            "id": [1,2],"name": ["baz": "qux"],"address":["surat","baroda"],"mon":["4545454545","5656565656"],"img":["bset.jpg","bset.jpg"]
        ]
        
        // Both calls are equivalent
        print(Alamofire.request("http://localhost/KrimaDB/postJsonInsert.php", method: .post, parameters: parameters, encoding: JSONEncoding.default))
        
        print(Alamofire.request("http://localhost/KrimaDB/postJsonInsert.php", method: .post, parameters: parameters, encoding: JSONEncoding(options: [])))*/

    
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }


}

