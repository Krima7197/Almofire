

import UIKit
import Alamofire

class ViewController: UIViewController
{

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var mob: UITextField!
    @IBOutlet weak var add: UITextField!
    
    @IBAction func click(_ sender: Any)
    {
        /*Alamofire.request("http://localhost/KrimaDB/SerivceInsertInDB.php?id=\(id.text!)&name=\(name.text!)&address=\(add.text!)&mon=\(mob.text!)").responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            
           /* if let json = response.result.value {
                print("JSON: \(json)") // serialized json response
            }*/
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print("Data: \(utf8Text)") // original server data as UTF8 string
            }
        }*/
        

        //SerivceGetFromDB
        
    }
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    
        /*Alamofire.request("http://localhost/KrimaDB/postJsonInsert.php?id=2&name=hhhj&address=hj&mon=4444444444&img=bset.jpg").responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            print(response.result.value ?? "ffh")
            
            
            if let json = response.result.value
            {
                print("JSON: \(json)") // serialized json response
            }
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8)
            {
                print("Data: \(utf8Text)") // original server data as UTF8 string
            }
        }*/
        
        
        let parameters: Parameters = [
            "id": [1,2],"name": ["baz": "qux"],"address":["surat","baroda"],"mon":["4545454545","5656565656"],"img":["bset.jpg","bset.jpg"]
        ]
        
        // Both calls are equivalent
        print(Alamofire.request("http://localhost/KrimaDB/postJsonInsert.php", method: .post, parameters: parameters, encoding: JSONEncoding.default))
        
        print(Alamofire.request("http://localhost/KrimaDB/postJsonInsert.php", method: .post, parameters: parameters, encoding: JSONEncoding(options: [])))

    
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }


}

